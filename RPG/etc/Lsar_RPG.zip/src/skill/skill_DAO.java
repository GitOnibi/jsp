package skill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class skill_DAO {
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement ptmt;
	
	public skill_tree getskillList(Object o_code) throws SQLException{
		System.out.println("skill_get");
		int code = (int) o_code;
		String sql="select * from skill where code="+code;
		System.out.println(sql);
		try {
			conn=DriverManager.getConnection("jdbc:apache:commons:dbcp:jkr");
			ptmt=conn.prepareStatement(sql);
			rs=ptmt.executeQuery();
			if(rs.next()) {
				skill_tree data=new skill_tree(
						rs.getString("skill_name"),
						rs.getString("skill_type"),
						rs.getString("skill_kind"),
						rs.getInt("skill_option1"),
						rs.getInt("skill_option2"),
						rs.getInt("skill_option3"),
						rs.getInt("skill_option4")
						);
				return data;
			}
			
			}catch(SQLException e) {
				System.out.println("getskill"+e);
			}finally {
				rs.close();
				ptmt.close();
			}
		return null;
	}
	public List<Integer> getcode(String id) throws SQLException{
		System.out.println("code get");
		List<Integer> list = new ArrayList<Integer>();
		String sql="select id from "+id+" where type='skill'";
		System.out.println(sql);
		try {
			conn=DriverManager.getConnection("jdbc:apache:commons:dbcp:jkr");
			ptmt=conn.prepareStatement(sql);
			rs=ptmt.executeQuery();
			while(rs.next()) {
				list.add(rs.getInt("id"));
			}
			return list;
		}catch(SQLException e) {
			System.out.println("getcode"+e);
		}finally {
			rs.close();
			ptmt.close();
		}
		return null;
	}
}
